﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarsRover
{
    public enum Direction
    {
        N=1,
        E = 2,
        S =3,
        W = 4
    }
}
