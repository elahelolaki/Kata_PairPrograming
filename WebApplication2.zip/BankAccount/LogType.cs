﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    public enum LogType
    {
        Deposit=1,
        Withdraw=2
    }
}
