﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTac
{
    public enum PlaySquare
    {
        N=0,
        X=Player.X,
        O=Player.O
    }
}
