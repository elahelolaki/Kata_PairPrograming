﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTac
{
    public enum PlayResult
    {
        Unknown=0,
        WinX=1,
        WinO=2
    }
}
