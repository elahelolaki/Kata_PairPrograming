﻿using System;

namespace TicTac
{
    public enum Player
    {
        X=1,
        O=2
    }
}
