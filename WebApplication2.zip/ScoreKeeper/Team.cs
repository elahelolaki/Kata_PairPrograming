﻿using System;

namespace ScoreKeeper
{
    public enum Team
    {
        A=0,
        B=1
    }
}
