﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnusualSpending
{
    public enum Category
    {
        entertainment=0, 
        restaurants=1,
        golf=2,
        groceries=3,
        travel=4
    }
}
