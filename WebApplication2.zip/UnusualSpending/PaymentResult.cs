﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnusualSpending
{
    public class PaymentResult
    {
        public Category Category { get; set; }

        public int Total { get; set; }
    }
}
