﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roman
{
    public enum SymbolOnes
    {
        I=1,
        V=5,
        X=10
    }

    public enum SymbolTens
    {
        X = 1,
        L = 5,
        C = 10
    }

    public enum SymbolHundredss
    {
        C = 1,
        D = 5,
        M = 10
    }
}
